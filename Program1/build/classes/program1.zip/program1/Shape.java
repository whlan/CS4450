/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package program1;

/**
 *
 * @author Willie Lan
 */
public interface Shape {

    /**
     * PURPOSE: draw this shape on GL projection matrix
     */
    public void draw(); 

    /**
     * PURPOSE: return some information about this shape
     */
    public String toString();
}
