/***************************************************************
* file: Shape.java
* author: Wei-Hao Lan
* class: CS 4450 – Computer Graphics
*
* assignment: program 1
* date last modified: 2/11/2019
*
* purpose: This class help us to draw the shape on GL and get the information
* from the this shape.
****************************************************************/
package program1;

/**
 *
 * @author Willie Lan
 */
public interface Shape {


     // PURPOSE: draw this shape on GL projection matrix
    public void draw(); 


     //PURPOSE: return some information about this shape
    public String toString();
}
