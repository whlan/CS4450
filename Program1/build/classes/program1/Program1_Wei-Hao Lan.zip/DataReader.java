/***************************************************************
* file: DataReader.java
* author: Wei-Hao Lan
* class: CS 4450 – Computer Graphics
*
* assignment: program 1
* date last modified: 2/11/2019
*
* purpose: Read in txt files. It split the letter and coordinates so we know
* the points is for what shape by the letter.
****************************************************************/
package program1;

import java.util.List;
import java.util.ArrayList;
import java.io.*;

/**
 *
 * @author Willie Lan
 */
public class DataReader {
    //private ArrayList<Shape> list;
    private List<Shape> list;


     // This constructor constructs data read from txt

    public DataReader(String filePath) {
        list = new ArrayList<>(); 
        try {
            BufferedReader reader = new BufferedReader(new FileReader(filePath));
            String line; 
            while ( (line = reader.readLine()) != null) {
                String[] data = line.split(" ");
                //condition for ellipse
                if (data[0].equals("l")) {
                    Point p1 = new Point(data[1].split(","));
                    Point p2 = new Point(data[2].split(","));
                    list.add(new Line(p1, p2));
                }
                // condition for circle
                else if (data[0].equals("c")) {
                    Point center = new Point(data[1].split(","));
                    float radius = Float.parseFloat(data[2]);
                    list.add(new Circle(center, radius));
                }
                //condition for ellipse
                else if (data[0].equals("e")) {
                    Point center = new Point(data[1].split(","));
                    String[] r = data[2].split(",");
                    float rx = Float.parseFloat(r[0]);
                    float ry = Float.parseFloat(r[1]);
                    list.add(new Ellipse(center, rx, ry));
                }
                else 
                    System.out.println("Provided shape is not provided. PASS.");
            }
            reader.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    //METHOD: getData
    //PURPOSE: get list from DataReader object
    public List<Shape> getData() {
        return list;
    }
}